import SwiftUI
import UIKit

// MARK: - Image Canvas with Resizable Rectangle
struct ImageCanvasView: View {
    @Binding var image: UIImage?
    @ObservedObject var rectangleManager: RectangleManager
    @Binding var imageDisplayRect: CGRect
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Display the image
                if let img = image {
                    Image(uiImage: img)
                        .resizable()
                        .scaledToFit()
                        .background(
                            GeometryReader { geo in
                                Color.clear
                                    .onAppear { imageDisplayRect = geo.frame(in: .local) }
                                    .onChange(of: geo.size) { _ in imageDisplayRect = geo.frame(in: .local) }
                            }
                        )
                } else {
                    Text("No Image")
                        .foregroundColor(.gray)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
                
                // Rectangle overlay
                ResizableRectangle(rect: $rectangleManager.rect,
                                   containerSize: image != nil ? imageDisplayRect.size : geometry.size)
            }
            .onAppear {
                if rectangleManager.rect == .zero {
                    // Initialize rectangle in the center
                    let w = geometry.size.width / 3
                    let h = geometry.size.height / 6
                    rectangleManager.rect = CGRect(x: (geometry.size.width - w)/2,
                                                  y: (geometry.size.height - h)/2,
                                                  width: w,
                                                  height: h)
                }
            }
        }
    }
}

// MARK: - Resizable Rectangle
struct ResizableRectangle: View {
    @Binding var rect: CGRect
    let containerSize: CGSize
    
    @State private var dragOffset: CGSize = .zero
    
    var body: some View {
        ZStack {
            // Rectangle outline
            Rectangle()
                .stroke(Color.red, lineWidth: 2)
                .frame(width: rect.width, height: rect.height)
                .position(x: rect.midX + dragOffset.width,
                          y: rect.midY + dragOffset.height)
                .gesture(moveGesture)
            
            // Corner handles
            ForEach(Corner.allCases, id: \.self) { corner in
                CornerHandle(corner: corner, rect: $rect, containerSize: containerSize)
            }
        }
    }
    
    // Move the rectangle
    private var moveGesture: some Gesture {
        DragGesture()
            .onChanged { value in
                dragOffset = value.translation
            }
            .onEnded { value in
                var newRect = rect
                newRect.origin.x += value.translation.width
                newRect.origin.y += value.translation.height
                
                newRect.origin.x = max(0, min(newRect.origin.x, containerSize.width - newRect.width))
                newRect.origin.y = max(0, min(newRect.origin.y, containerSize.height - newRect.height))
                
                rect = newRect
                dragOffset = .zero
            }
    }
}

// MARK: - Corner Handles
enum Corner: CaseIterable {
    case topLeft, topRight, bottomLeft, bottomRight
}

struct CornerHandle: View {
    let corner: Corner
    @Binding var rect: CGRect
    let containerSize: CGSize
    
    @State private var startRect: CGRect = .zero
    
    var body: some View {
        Circle()
            .fill(Color.red)
            .frame(width: 15, height: 15)
            .position(position)
            .gesture(resizeGesture)
    }
    
    private var position: CGPoint {
        switch corner {
        case .topLeft: return CGPoint(x: rect.minX, y: rect.minY)
        case .topRight: return CGPoint(x: rect.maxX, y: rect.minY)
        case .bottomLeft: return CGPoint(x: rect.minX, y: rect.maxY)
        case .bottomRight: return CGPoint(x: rect.maxX, y: rect.maxY)
        }
    }
    
    private var resizeGesture: some Gesture {
        DragGesture()
            .onChanged { value in
                if startRect == .zero { startRect = rect }
                var newRect = startRect
                let minSize: CGFloat = 50
                
                switch corner {
                case .topLeft:
                    newRect.origin.x += value.translation.width
                    newRect.size.width -= value.translation.width
                    newRect.origin.y += value.translation.height
                    newRect.size.height -= value.translation.height
                case .topRight:
                    newRect.size.width += value.translation.width
                    newRect.origin.y += value.translation.height
                    newRect.size.height -= value.translation.height
                case .bottomLeft:
                    newRect.origin.x += value.translation.width
                    newRect.size.width -= value.translation.width
                    newRect.size.height += value.translation.height
                case .bottomRight:
                    newRect.size.width += value.translation.width
                    newRect.size.height += value.translation.height
                }
                
                if newRect.width >= minSize && newRect.height >= minSize &&
                   newRect.minX >= 0 && newRect.maxX <= containerSize.width &&
                   newRect.minY >= 0 && newRect.maxY <= containerSize.height {
                    rect = newRect
                }
            }
            .onEnded { _ in
                startRect = .zero
            }
    }
}
