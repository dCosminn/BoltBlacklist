import UIKit
import Vision
import SwiftUI

class OCRService {
    static let shared = OCRService()

    func recognizeText(
        in image: UIImage,
        rect: CGRect,
        imageDisplayRect: CGRect,
        showDebug: Bool = true,
        completion: @escaping (Result<String, Error>) -> Void
    ) {
        guard let cgImage = image.cgImage else {
            completion(.failure(OCRError.invalidImage))
            return
        }

        // Correct crop for displayRect → image coordinates
        let cropRect = calculateCropRect(
            overlayRect: rect,
            imageSize: image.size,
            imageScale: image.scale,
            displayRect: imageDisplayRect
        )

        if showDebug {
            print("Overlay rect: \(rect)")
            print("Image display rect: \(imageDisplayRect)")
            print("Crop rect (pixels): \(cropRect)")
        }

        guard let croppedCGImage = cgImage.cropping(to: cropRect) else {
            completion(.failure(OCRError.croppingFailed))
            return
        }

        if showDebug {
            let debugImage = UIImage(cgImage: croppedCGImage)
            DispatchQueue.main.async {
                DebugOverlay.shared.show(image: debugImage)
            }
        }

        let request = VNRecognizeTextRequest { request, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            guard let observations = request.results as? [VNRecognizedTextObservation] else {
                completion(.failure(OCRError.noResults))
                return
            }

            let text = observations
                .compactMap { $0.topCandidates(1).first?.string }
                .joined(separator: "\n")
                .trimmingCharacters(in: .whitespacesAndNewlines)

            completion(.success(text))
        }

        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = true

        let handler = VNImageRequestHandler(cgImage: croppedCGImage, options: [:])
        DispatchQueue.global(qos: .userInitiated).async {
            try? handler.perform([request])
        }
    }

    private func calculateCropRect(
        overlayRect: CGRect,
        imageSize: CGSize,
        imageScale: CGFloat,
        displayRect: CGRect
    ) -> CGRect {
        // Convert to pixels
        let pixelWidth = imageSize.width * imageScale
        let pixelHeight = imageSize.height * imageScale

        let imageAspect = imageSize.width / imageSize.height
        let displayAspect = displayRect.width / displayRect.height

        var scale: CGFloat = 1
        var xOffset: CGFloat = 0
        var yOffset: CGFloat = 0

        if imageAspect > displayAspect {
            // Fit width, letterbox vertically
            scale = pixelWidth / displayRect.width
            let scaledHeight = displayRect.width / imageAspect
            yOffset = (displayRect.height - scaledHeight) / 2
        } else {
            // Fit height, letterbox horizontally
            scale = pixelHeight / displayRect.height
            let scaledWidth = displayRect.height * imageAspect
            xOffset = (displayRect.width - scaledWidth) / 2
        }

        let imageX = (overlayRect.minX - displayRect.minX - xOffset) * scale
        let imageY = (overlayRect.minY - displayRect.minY - yOffset) * scale
        let imageWidth = overlayRect.width * scale
        let imageHeight = overlayRect.height * scale

        return CGRect(
            x: max(0, min(imageX, pixelWidth)),
            y: max(0, min(imageY, pixelHeight)),
            width: min(imageWidth, pixelWidth - imageX),
            height: min(imageHeight, pixelHeight - imageY)
        )
    }

    func extractKey(from text: String) -> String {
        text.components(separatedBy: "-")
            .first?
            .trimmingCharacters(in: .whitespaces)
            .uppercased() ?? ""
    }
}

enum OCRError: LocalizedError {
    case invalidImage
    case croppingFailed
    case noResults

    var errorDescription: String? {
        switch self {
        case .invalidImage: return "Invalid image"
        case .croppingFailed: return "Failed to crop image"
        case .noResults: return "No text found"
        }
    }
}

// Debug overlay
class DebugOverlay {
    static let shared = DebugOverlay()
    private var window: UIWindow?

    func show(image: UIImage) {
        if window == nil {
            window = UIWindow(frame: UIScreen.main.bounds)
            window?.windowLevel = .alert + 1
            window?.backgroundColor = UIColor.black.withAlphaComponent(0.7)
            window?.rootViewController = UIViewController()
            window?.isHidden = false
        }

        let imageView = UIImageView(image: image)
        imageView.contentMode = .scaleAspectFit
        imageView.frame = window!.bounds
        window!.rootViewController?.view.subviews.forEach { $0.removeFromSuperview() }
        window!.rootViewController?.view.addSubview(imageView)
    }
}
